
var serverlessSDK = require('./serverless_sdk/index.js');
serverlessSDK = new serverlessSDK({
  orgId: 'ensyex',
  applicationName: 'engineering-test',
  appUid: 'nnlGKFmCp9xX7L1tcZ',
  orgUid: 'vWBbJmB7lwb0L2yCbx',
  deploymentUid: '70f0f841-cb7f-4cae-8886-d09386dde39d',
  serviceName: 'engineering-test',
  shouldLogMeta: true,
  shouldCompressLogs: true,
  disableAwsSpans: false,
  disableHttpSpans: false,
  stageName: 'dev',
  serverlessPlatformStage: 'prod',
  devModeEnabled: false,
  accessKey: null,
  pluginVersion: '4.1.2',
  disableFrameworksInstrumentation: false
});

const handlerWrapperArgs = { functionName: 'engineering-test-dev-GetPaginatedTransactions', timeout: 6 };

try {
  const userHandler = require('./handler.js');
  module.exports.handler = serverlessSDK.handler(userHandler.GetPaginatedTransactions, handlerWrapperArgs);
} catch (error) {
  module.exports.handler = serverlessSDK.handler(() => { throw error }, handlerWrapperArgs);
}